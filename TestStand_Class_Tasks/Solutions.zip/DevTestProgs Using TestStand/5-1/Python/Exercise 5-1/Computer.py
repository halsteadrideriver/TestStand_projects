class Computer(object):
    
    def __init__(self, dialogData):
        self.dialogData = {'PowerFail':dialogData[0], 'CPUFail':dialogData[1], 'ROMFail':dialogData[2], 'RAMFail':dialogData[3], 'KeyboardValue': dialogData[4], 'VideoValue':dialogData[5] }

    def VacuumOn(self):
        try:
            """Turns Vacuum Table On"""
        except Exception as e:
            raise Exception('Vacuum Table Failed to Intialize: ' + str(e))

    def PowerupTest(self):
        try:
            """Powerup Test"""
            return not self.dialogData['PowerFail']
        except Exception as e:
            raise Exception('Powerup Test encountered an error: ' + str(e))

    def RegisterTest(self):
        try:
            """Register Test"""
            return True
        except Exception as e:
            raise Exception('Register test encountered an error: ' + str(e))

    def InstrSetTest(self):
        try:
            """Instruction Set Test"""
            return not self.dialogData['CPUFail']
        except Exception as e:
            raise Exception('Instruction set test encountered an error: ' + str(e))

    def CacheTest(self):
        try:
            """Cache Test"""
            return True
        except Exception as e:
            raise Exception('Cache test encountered an error: ' + str(e))

    def FPUTest(self):
        try:
            """FPU Test"""
            return True
        except Exception as e:
            raise Exception('FPU test encountered an error: ' + str(e))

    def ROMTest(self):
        try:
            """ROM Test"""
            return not self.dialogData['ROMFail']
        except Exception as e:
            raise Exception('ROM test encountered an error: ' + str(e))

    def RAMTest(self):
        try:
            """RAM Test"""
            return not self.dialogData['RAMFail']
        except Exception as e:
            raise Exception('RAM test encountered an error: ' + str(e))

    def VideoTest(self):
        try:
            """Video Test"""
            return self.dialogData['VideoValue']
        except Exception as e:
            raise Exception('Video test encountered an error: ' + str(e))

    def KeyboardTest(self):
        try:
            """Keyboard Test"""
            return self.dialogData['KeyboardValue']
        except Exception as e:
            raise Exception('Keyboard test encountered an error: ' + str(e))

   
    def VacuumOff(self):
        try:
            """Turns Vacuum Table Off"""
        except Exception as e:
            raise Exception('Vacuum Table Failed to Shutdown: ' + str(e))
