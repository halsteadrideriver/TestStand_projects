from instrument_simulation import *

def controller_board_thermal_test(powerSupply, lineiInVoltage, dmm):
    #Change environmental setting which effects all UUTs in the test fixture
    TestFixture.set_environment(environment=Environment.Temperature, value=60)

    #Generate DC voltage with Power Supply
    powerSupply.generate_voltage_dc(channel=0, socket=0, output_voltage=lineiInVoltage)

    #Read temperature with DMM and assign to Temperature variable
    temperature = dmm.read_temperature(channel=10, socket=0, sensor_type=TemperatureSensor.KTypeThermocouple)

    #Return the temperature value read
    return temperature
