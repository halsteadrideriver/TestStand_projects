from instrument_simulation import *

def voltage_output_test(powerSupply, lineInVoltage, dmm, signalType, dmmChannel):

    #Generate DC voltage with Power Supply
    powerSupply.generate_voltage_dc(channel=0, socket=0, output_voltage=lineInVoltage)

    #Configure the DMM to read
    dmm.configure(signalType)

    #Read voltage value with DMM
    voltageRead = dmm.read_voltage(channel=dmmChannel, socket=0)

    return voltageRead