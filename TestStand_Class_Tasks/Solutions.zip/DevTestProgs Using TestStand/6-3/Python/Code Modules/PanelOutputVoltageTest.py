from instrument_simulation import*

def panel_output_voltage_test(dmm):
    #Configure the DMM to read
    dmm.configure(SignalType.DC)

    #Read voltage value with DMM
    voltageRead = dmm.read_voltage(channel=6, socket=0)

    return voltageRead

