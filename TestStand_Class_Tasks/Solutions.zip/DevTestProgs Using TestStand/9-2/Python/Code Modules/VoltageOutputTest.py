from instrument_simulation import *

def voltage_output_test(powerSupply, lineInVoltage, dmm, signalType, dmmChannel, socket):

    #Generate DC voltage with Power Supply
    powerSupply.generate_voltage_dc(channel=0, socket=socket, output_voltage=lineInVoltage)

    #Configure the DMM to read
    dmm.configure(signalType)

    #Read voltage value with DMM
    voltageRead = dmm.read_voltage(channel=dmmChannel, socket=socket)

    return voltageRead

'''
if __name__ == "__main__":
    ps_1 = PowerSupply("ps4")
    dmm_1 = DMM("dmm4")

    voltage_read = voltage_output_test(ps_1, 20, dmm_1)
    print(voltage_read)

    ps_1.close()
    dmm_1.close()
'''